/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 11);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/js/nav.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/* import Ajax from './common/request'*/

$(document).click(function () {
    $('.community').removeClass('on');
    $('.email').removeClass('on');
});

$('.int-search').on('keyup', function () {
    var value = $(this).val();
    if (value.length != 0) {
        $('.blog-nav-search-m-top span').show();
        /* Ajax.getHTML('/mock/nav_m_search.html').then((res) => {
            $('.blog-nav-search-m-bottom').html(res)
        }) */
    } else {
        $('.blog-nav-search-m-top span').hide();
    }
});
$('.blog-nav-search-m-top span').click(function () {
    $('.int-search').val('');
    $(this).hide();
});
$('.show-search').data('flag', true);
$('.show-search').click(function () {
    var flag = $('.show-search').data('flag');
    if (flag) {
        $('body').css('overflow', 'hidden');
        $('.show-search').data('flag', false);
    } else {
        $('.show-search').data('flag', true);
        $('body').removeAttr('style');
    }
    $('.blog-nav-search-m').toggle();
});
$('.show-more').data('flag', true);
$('.show-more').click(function () {
    var flag = $('.show-more').data('flag');
    if (flag) {
        $('body').css('overflow', 'hidden');
        $('.show-more').data('flag', false);
    } else {
        $('.show-more').data('flag', true);
        $('body').removeAttr('style');
    }
    if (window.configs.islogin) {
        $('.login-in').show();
    }
    $('.blog-nav-main-m').toggle();
});

$('.select-more>div').click(function () {
    $(this).parent().toggleClass('on');
});
$('.logout').css('display', 'block');
if (!window.configs.islogin) {
    // $('.community,.email').hide()
} else {
    $('.free,.login').hide();
    $('.community div').click(function () {
        $(this).parent().toggleClass('on');
        $('.email').removeClass('on');
        return false;
    });
    $('.email>div').click(function () {
        $(this).parent().toggleClass('on');
        $('.community').removeClass('on');
        /* $(this).children('span').hide()
          if ($(this).parent().children('section').children('main').children('div').length == 0) {
             Ajax.getHTML('/mock/nav_email.html').then((res) => {
                 $(this).parent().children('section').children('main').html(res)
                 $(this).children('.email-icon').removeClass('new')
             })
         } */

        return false;
    });
}

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./src/js/nav.js");


/***/ })

/******/ });