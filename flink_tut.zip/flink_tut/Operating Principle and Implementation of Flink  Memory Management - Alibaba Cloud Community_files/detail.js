/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/_mditor@1.3.3@mditor/dist/css/mditor.css":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "./node_modules/_webpack@3.11.0@webpack/buildin/module.js":
/***/ (function(module, exports) {

module.exports = function(module) {
	if(!module.webpackPolyfill) {
		module.deprecate = function() {};
		module.paths = [];
		// module.parent = undefined by default
		if(!module.children) module.children = [];
		Object.defineProperty(module, "loaded", {
			enumerable: true,
			get: function() {
				return module.l;
			}
		});
		Object.defineProperty(module, "id", {
			enumerable: true,
			get: function() {
				return module.i;
			}
		});
		module.webpackPolyfill = 1;
	}
	return module;
};


/***/ }),

/***/ "./src/css/detail.css":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "./src/css/nav.css":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "./src/js/common/dialog.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '<div class="dialog ';
 if(option.dialogtype) { ;
__p +=
((__t = (option.dialogtype)) == null ? '' : __t);
 } ;
__p += ' ';
 if(option.size) { ;
__p +=
((__t = (option.size)) == null ? '' : __t);
 } ;
__p += '">\n  <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">\n    <symbol id="dialog-right" viewBox="0 0 1024 1024">\n      <title>dialog-right</title>\n      <path d="M512 0c-282.8 0-512 229.2-512 512s229.2 512 512 512c282.768 0 512-229.2 512-512s-229.232-512-512-512v0 0zM512 976c-256.265 0-464-207.735-464-464s207.735-464 464-464c256.265 0 464 207.735 464 464s-207.735 464-464 464v0 0zM833.168 343.735l-381.833 381.863c-6.336 6.265-14.567 9.401-22.8 9.335-8.233 0-16.464-3.072-22.736-9.335l-214.969-215.001c-12.496-12.464-12.496-32.736 0-45.264 12.505-12.464 32.768-12.464 45.232 0l192.464 192.464 359.337-359.335c12.496-12.464 32.8-12.464 45.305 0 12.496 12.535 12.496 32.8 0 45.271v0 0zM833.168 343.735z" p-id="1641"></path>\n    </symbol>\n    <symbol id="dialog-error" viewBox="0 0 1024 1024">\n      <title>dialog-error</title>\n      <path d="M516.461 20.457c-274.346 0-496.742 222.394-496.742 496.742s222.394 496.742 496.742 496.742 496.742-222.394 496.742-496.742-222.394-496.742-496.742-496.742zM516.461 964.278c-246.527 0-447.079-200.547-447.079-447.079s200.547-447.079 447.079-447.079 447.079 200.547 447.079 447.079-200.547 447.079-447.079 447.079z" fill="" p-id="2385"></path><path d="M741.978 291.67c-12.099-12.117-31.79-12.117-43.905 0l-181.633 181.633-181.633-181.633c-12.102-12.117-31.795-12.117-43.905 0-12.117 12.102-12.117 31.79 0 43.905l181.633 181.633-181.633 181.633c-12.117 12.102-12.117 31.79 0 43.905 6.032 6.061 13.984 9.073 21.942 9.073 7.926 0 15.886-3.03 21.942-9.073l181.633-181.633 181.633 181.633c6.061 6.061 14.002 9.073 21.942 9.073s15.886-3.03 21.942-9.073c12.117-12.102 12.117-31.79 0-43.905l-181.669-181.633 181.633-181.633c12.117-12.102 12.117-31.79 0-43.905z" p-id="2386"></path>\n    </symbol>\n  </svg>\n  ';
 if(option.type&&option.type=="success") { ;
__p += '  \n    <i class="dialog-icon">\n        <svg class="icon-right">\n          <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#dialog-right"></use>\n        </svg>\n    </i>\n  ';
 } ;
__p += ' \n  ';
 if(option.type&&option.type=="error") { ;
__p += '  \n    <i class="dialog-icon">\n        <svg class="icon-error">\n          <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#dialog-error"></use>\n        </svg>\n    </i>\n  ';
 } ;
__p += '\n  ';
 if(option.type&&option.type=="prompt") { ;
__p += '  \n    <i class="dialog-icon">\n        <img src="https://img.alicdn.com/tfs/TB1bNtfoQCWBuNjy0FaXXXUlXXa-72-72.png" alt="">\n    </i>\n  ';
 } ;
__p += '\n  ';
 if(option.title) { ;
__p += '  \n    <div class="dialog-title">' +
((__t = (option.title)) == null ? '' : __t) +
'</div>\n  ';
 } ;
__p += ' \n  ';
 if(typeof option.content == "string") { ;
__p += '  \n    <div class="dialog-content">' +
((__t = (option.content)) == null ? '' : __t) +
'</div>\n  ';
 }else if(typeof option.content != "undefined"){ ;
__p += '  \n    <div class="dialog-content"></div> \n  ';
 } ;
__p += '   \n  ';
 if(option.btns&&option.complexBtns.length>0) { ;
__p += '  \n    <div class="dialog-btn">\n        ';
 option.complexBtns.forEach(function(e){ ;
__p += '  \n          <a id="' +
((__t = (e.id)) == null ? '' : __t) +
'">' +
((__t = (e.text)) == null ? '' : __t) +
'</a>\n        ';
 }) ;
__p += '  \n    </div>\n  ';
 } ;
__p += ' \n</div>';

}
return __p
}

/***/ }),

/***/ "./src/js/common/dialog.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _jquery = __webpack_require__("jquery");

var _jquery2 = _interopRequireDefault(_jquery);

var _jquery3 = __webpack_require__("./src/js/common/jquery.modal.js");

var _jquery4 = _interopRequireDefault(_jquery3);

var _dialog = __webpack_require__("./src/js/common/dialog.ejs");

var _dialog2 = _interopRequireDefault(_dialog);

__webpack_require__("./src/js/common/dialog.less");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Dialog = function () {
  function Dialog() {
    _classCallCheck(this, Dialog);
  }

  _createClass(Dialog, null, [{
    key: 'dialog',
    value: function dialog(option) {
      var options = _jquery2.default.extend({}, { title: 'Title',
        content: "Content",
        size: '',
        btns: [] }, option ? option : {});
      var complexBtns = [];
      options.btns.forEach(function (element, index) {
        var text = typeof element == "string" ? element : element.text;
        complexBtns.push({
          text: text,
          id: element.id ? element.id : "btn" + index,
          fn: element.fn ? element.fn : function () {
            return true;
          }
        });
      });
      options.complexBtns = complexBtns;
      var $el = (0, _jquery2.default)('<div class="dialog  ' + options.size + ' ">' + (0, _dialog2.default)({ option: options }) + '</div>');

      if (typeof option.content != "string") {
        $el.find('.dialog-content').append(options.content.clone(true, true).show());
      }
      options.complexBtns.forEach(function (element) {
        $el.on('click', "#" + element.id, function () {
          if (element.fn()) {
            _jquery2.default.jqmodal.close();
          }
        });
      });
      $el.jqmodal({ closeExisting: false });
      // $el.modal({closeExisting: false});
      return $el;
    }
  }, {
    key: 'popEl',
    value: function popEl($el, option) {
      var options = _jquery2.default.extend({}, { closeExisting: false, showClose: false }, option);
      $el.jqmodal(options);
      // $el.modal(options);
      return $el;
    }
  }, {
    key: 'alertSuccess',
    value: function alertSuccess(title, content, option) {
      return Dialog.dialog(_jquery2.default.extend({}, { title: title, content: content, dialogtype: 'alert', type: 'success' }, option));
    }
  }, {
    key: 'alertError',
    value: function alertError(title, content, option) {
      return Dialog.dialog(_jquery2.default.extend({}, { title: title, content: content, dialogtype: 'alert', type: 'error' }, option));
    }
  }, {
    key: 'notifyError',
    value: function notifyError(content, option) {
      var options = _jquery2.default.extend({}, { title: content, dialogtype: 'notify', type: 'error' }, option ? option : {});
      var $el = (0, _jquery2.default)((0, _dialog2.default)({ option: options }));
      return Dialog.popEl($el, { showClose: true });
    }
  }, {
    key: 'notifySuccess',
    value: function notifySuccess(content, option) {
      var options = _jquery2.default.extend({}, { title: content, dialogtype: 'notify', type: 'success' }, option ? option : {});
      var $el = (0, _jquery2.default)((0, _dialog2.default)({ option: options }));
      return Dialog.popEl($el, { showClose: true });
    }
  }, {
    key: 'notifyPrompt',
    value: function notifyPrompt(content, option) {
      var options = _jquery2.default.extend({}, { title: content, dialogtype: 'notify notifyPrompt', type: 'prompt' }, option ? option : {});
      var $el = (0, _jquery2.default)((0, _dialog2.default)({ option: options }));
      return Dialog.popEl($el, { showClose: true });
    }
  }, {
    key: 'alertPrompt',
    value: function alertPrompt(title, content, option) {
      return Dialog.dialog(_jquery2.default.extend({}, { title: title, content: content, dialogtype: 'notify', type: 'prompt' }, option));
    }
  }]);

  return Dialog;
}();

exports.default = Dialog;

/***/ }),

/***/ "./src/js/common/dialog.less":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "./src/js/common/jquery.modal.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

(function (factory) {
  // Making your jQuery plugin work better with npm tools
  // http://blog.npmjs.org/post/112712169830/making-your-jquery-plugin-work-better-with-npm
  if (( false ? "undefined" : _typeof(module)) === "object" && _typeof(module.exports) === "object") {
    factory(__webpack_require__("jquery"), window, document);
  } else {
    factory(jQuery, window, document);
  }
})(function ($, window, document, undefined) {
  if ($.modal) {
    $.modal_back = $.modal;
  }
  if ($.fn.modal) {
    $.fn.modal_back = $.fn.modal;
  }
  var modals = [],
      getCurrent = function getCurrent() {
    return modals.length ? modals[modals.length - 1] : null;
  },
      selectCurrent = function selectCurrent() {
    var i,
        selected = false;
    for (i = modals.length - 1; i >= 0; i--) {
      if (modals[i].$blocker) {
        modals[i].$blocker.toggleClass('current', !selected).toggleClass('behind', selected);
        selected = true;
      }
    }
  };

  $.modal = function (el, options) {
    var remove, target;
    this.$body = $('body');
    this.options = $.extend({}, $.modal.defaults, options);
    this.options.doFade = !isNaN(parseInt(this.options.fadeDuration, 10));
    this.$blocker = null;
    if (this.options.closeExisting) while ($.modal.isActive()) {
      $.modal.close();
    } // Close any open modals.
    modals.push(this);
    if (el.is('a')) {
      target = el.attr('href');
      this.anchor = el;
      //Select element by id from href
      if (/^#/.test(target)) {
        this.$elm = $(target);
        if (this.$elm.length !== 1) return null;
        this.$body.append(this.$elm);
        this.open();
        //AJAX
      } else {
        this.$elm = $('<div>');
        this.$body.append(this.$elm);
        remove = function remove(event, modal) {
          modal.elm.remove();
        };
        this.showSpinner();
        el.trigger($.modal.AJAX_SEND);
        $.get(target).done(function (html) {
          if (!$.modal.isActive()) return;
          el.trigger($.modal.AJAX_SUCCESS);
          var current = getCurrent();
          current.$elm.empty().append(html).on($.modal.CLOSE, remove);
          current.hideSpinner();
          current.open();
          el.trigger($.modal.AJAX_COMPLETE);
        }).fail(function () {
          el.trigger($.modal.AJAX_FAIL);
          var current = getCurrent();
          current.hideSpinner();
          modals.pop(); // remove expected modal from the list
          el.trigger($.modal.AJAX_COMPLETE);
        });
      }
    } else {
      this.$elm = el;
      this.anchor = el;
      this.$body.append(this.$elm);
      this.open();
    }
  };

  $.modal.prototype = {
    constructor: $.modal,

    open: function open() {
      var m = this;
      this.block();
      this.anchor.blur();
      if (this.options.doFade) {
        setTimeout(function () {
          m.show();
        }, this.options.fadeDuration * this.options.fadeDelay);
      } else {
        this.show();
      }
      $(document).off('keydown.modal').on('keydown.modal', function (event) {
        var current = getCurrent();
        if (event.which === 27 && current.options.escapeClose) current.close();
      });
      if (this.options.clickClose) this.$blocker.click(function (e) {
        if (e.target === this) $.modal.close();
      });
    },

    close: function close() {
      modals.pop();
      this.unblock();
      this.hide();
      if (!$.modal.isActive()) $(document).off('keydown.modal');
    },

    block: function block() {
      this.$elm.trigger($.modal.BEFORE_BLOCK, [this._ctx()]);
      this.$body.css('overflow', 'hidden');
      this.$blocker = $('<div class="' + this.options.blockerClass + ' blocker current"></div>').appendTo(this.$body);
      selectCurrent();
      if (this.options.doFade) {
        this.$blocker.css('opacity', 0).animate({ opacity: 1 }, this.options.fadeDuration);
      }
      this.$elm.trigger($.modal.BLOCK, [this._ctx()]);
    },

    unblock: function unblock(now) {
      if (!now && this.options.doFade) this.$blocker.fadeOut(this.options.fadeDuration, this.unblock.bind(this, true));else {
        this.$blocker.children().appendTo(this.$body);
        this.$blocker.remove();
        this.$blocker = null;
        selectCurrent();
        if (!$.modal.isActive()) this.$body.css('overflow', '');
      }
    },

    show: function show() {
      this.$elm.trigger($.modal.BEFORE_OPEN, [this._ctx()]);
      if (this.options.showClose) {
        this.closeButton = $('<a href="#close-modal" rel="modal:close" class="close-modal ' + this.options.closeClass + '">' + this.options.closeText + '</a>');
        this.$elm.append(this.closeButton);
      }
      this.$elm.addClass(this.options.modalClass).appendTo(this.$blocker);
      if (this.options.doFade) {
        this.$elm.css({ opacity: 0, display: 'inline-block' }).animate({ opacity: 1 }, this.options.fadeDuration);
      } else {
        this.$elm.css('display', 'inline-block');
      }
      this.$elm.trigger($.modal.OPEN, [this._ctx()]);
    },

    hide: function hide() {
      this.$elm.trigger($.modal.BEFORE_CLOSE, [this._ctx()]);
      if (this.closeButton) this.closeButton.remove();
      var _this = this;
      if (this.options.doFade) {
        this.$elm.fadeOut(this.options.fadeDuration, function () {
          _this.$elm.trigger($.modal.AFTER_CLOSE, [_this._ctx()]);
        });
      } else {
        this.$elm.hide(0, function () {
          _this.$elm.trigger($.modal.AFTER_CLOSE, [_this._ctx()]);
        });
      }
      this.$elm.trigger($.modal.CLOSE, [this._ctx()]);
    },

    showSpinner: function showSpinner() {
      if (!this.options.showSpinner) return;
      this.spinner = this.spinner || $('<div class="' + this.options.modalClass + '-spinner"></div>').append(this.options.spinnerHtml);
      this.$body.append(this.spinner);
      this.spinner.show();
    },

    hideSpinner: function hideSpinner() {
      if (this.spinner) this.spinner.remove();
    },

    //Return context for custom events
    _ctx: function _ctx() {
      return { elm: this.$elm, $elm: this.$elm, $blocker: this.$blocker, options: this.options };
    }
  };

  $.modal.close = function (event) {
    if (!$.modal.isActive()) return;
    if (event) event.preventDefault();
    var current = getCurrent();
    current.close();
    return current.$elm;
  };

  // Returns if there currently is an active modal
  $.modal.isActive = function () {
    return modals.length > 0;
  };

  $.modal.getCurrent = getCurrent;

  $.modal.defaults = {
    closeExisting: true,
    escapeClose: true,
    clickClose: true,
    closeText: 'Close',
    closeClass: '',
    modalClass: "jqmodal",
    blockerClass: "jquery-modal",
    spinnerHtml: '<div class="rect1"></div><div class="rect2"></div><div class="rect3"></div><div class="rect4"></div>',
    showSpinner: true,
    showClose: true,
    fadeDuration: null, // Number of milliseconds the fade animation takes.
    fadeDelay: 1.0 // Point during the overlay's fade-in that the modal begins to fade in (.5 = 50%, 1.5 = 150%, etc.)
  };

  // Event constants
  $.modal.BEFORE_BLOCK = 'modal:before-block';
  $.modal.BLOCK = 'modal:block';
  $.modal.BEFORE_OPEN = 'modal:before-open';
  $.modal.OPEN = 'modal:open';
  $.modal.BEFORE_CLOSE = 'modal:before-close';
  $.modal.CLOSE = 'modal:close';
  $.modal.AFTER_CLOSE = 'modal:after-close';
  $.modal.AJAX_SEND = 'modal:ajax:send';
  $.modal.AJAX_SUCCESS = 'modal:ajax:success';
  $.modal.AJAX_FAIL = 'modal:ajax:fail';
  $.modal.AJAX_COMPLETE = 'modal:ajax:complete';

  $.fn.modal = function (options) {
    if (this.length === 1) {
      new $.modal(this, options);
    }
    return this;
  };
  $.fn.jqmodal = $.fn.modal;
  $.jqmodal = $.modal;
  if ($.modal_back) {
    $.modal = $.modal_back;
  }

  if ($.fn.modal_back) {
    $.fn.modal = $.fn.modal_back;
  }
  // Automatically bind links with rel="modal:close" to, well, close the modal.
  $(document).on('click.modal', 'a[rel~="modal:close"]', $.modal.close);
  $(document).on('click.modal', 'a[rel~="modal:open"]', function (event) {
    event.preventDefault();
    $(this).modal();
  });
  return $;
});
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("./node_modules/_webpack@3.11.0@webpack/buildin/module.js")(module)))

/***/ }),

/***/ "./src/js/common/pager.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.default = Page;

var _dialog = __webpack_require__("./src/js/common/dialog.js");

var _dialog2 = _interopRequireDefault(_dialog);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Page(opt) {
	var set = $.extend({ num: null, startnum: 1, elem: null, callback: null }, opt || {});
	if (set.startnum > set.num || set.startnum < 1) {
		set.startnum = 1;
	}
	var n = 0,
	    htm = '';
	var clickpages = {
		elem: set.elem,
		num: set.num,
		callback: set.callback,
		count: 1,
		tabclick: set.tabclick,
		total: set.total,
		top: set.top,
		init: function init() {
			var tabclick = this.tabclick;
			var top = this.top == undefined ? 0 : this.top;
			$(tabclick).next('div.pageJump').children('.button').unbind('click');
			this.JumpPages();
			$(tabclick).children('li').click(function () {

				$(window).scrollTop(top);
				var txt = $(this).attr('page');
				var page = '',
				    ele = null;
				var page1 = parseInt($(tabclick).children('li.active').attr('page'));
				if (isNaN(parseInt(txt))) {
					switch (txt) {
						case 'next':
							if (page1 == clickpages.num) {
								return;
							}
							if (page1 >= clickpages.num - 2 || clickpages.num <= 6 || page1 < 3) {
								ele = $(tabclick).children('li.active').next();
							} else {
								clickpages.newPages('next', page1 + 1);
								ele = $(tabclick).children('li.active');
							}
							break;
						case 'prev':
							if (page1 == '1') {
								return;
							}
							if (page1 >= clickpages.num - 1 || page1 <= 3 || clickpages.num <= 6) {
								ele = $(tabclick).children('li.active').prev();
							} else {
								clickpages.newPages('prev', page1 - 1);
								ele = $(tabclick).children('li.active');
							}
							break;
						case 'first':
							if (page1 == '1') {
								return;
							}
							if (clickpages.num > 6) {
								clickpages.newPages('first', 1);
							}
							ele = $(tabclick).children('li[page=1]');
							break;
						case 'last':
							if (page1 == clickpages.num) {
								return;
							}
							if (clickpages.num > 6) {
								clickpages.newPages('last', clickpages.num);
							}
							ele = $(tabclick).children('li[page=' + clickpages.num + ']');
							break;
						case undefined:
							return;
					}
				} else {
					if ((parseInt(txt) >= clickpages.num - 3 || parseInt(txt) <= 3) && clickpages.num > 6) {
						clickpages.newPages('jump', parseInt(txt));
					}
					ele = $(this);
				}
				page = clickpages.actPages(ele);
				if (page != '' && page != page1) {
					if (clickpages.callback) {
						clickpages.callback(parseInt(page));
					}
				}
			});
		},
		//active
		actPages: function actPages(ele) {
			var tabclick = this.tabclick;
			ele.addClass('active').siblings().removeClass('active');
			return $(tabclick).children('li.active').text();
		},
		JumpPages: function JumpPages(num) {
			var tabclick = this.tabclick;
			var top = this.top == undefined ? 0 : this.top;
			$(tabclick).parent().next('div.pageJump').children('.button').click(function () {

				var i = parseInt($(this).siblings('input').val());
				if (isNaN(i) || i <= 0 || i > clickpages.num) {
					_dialog2.default.alertError('Prompt', "Please enter a legitimate page number!");
					return;
				} else if (clickpages.num > 6) {
					$(window).scrollTop(top);
					clickpages.newPages('jump', i);
				} else {
					var ele = clickpages.elem.find('li[page=' + i + ']');
					clickpages.actPages(ele);
					$(window).scrollTop(top);
					if (clickpages.callback) {
						clickpages.callback(i);
					}
					return;
				}

				if (clickpages.callback) {
					clickpages.callback(i);
				}
			});
		},

		//newpages
		newPages: function newPages(type, i) {
			var setId = this.tabclick.substr(1, this.tabclick.length);
			var html = "",
			    htmlLeft = "",
			    htmlRight = "",
			    htmlC = "";
			var HL = '<li><a>...</a></li>';
			for (var n = 0; n < 3; n++) {
				htmlC += '<li ' + (n - 1 == 0 ? 'class="active"' : '') + ' page="' + (i + n - 1) + '"><a>' + (i + n - 1) + '</a></li>';
				htmlLeft += '<li ' + (n + 2 == i ? 'class="active"' : '') + ' page="' + (n + 2) + '"><a>' + (n + 2) + '</a></li>';
				htmlRight += '<li ' + (set.num + n - 3 == i ? 'class="active"' : '') + ' page="' + (set.num + n - 3) + '"><a>' + (set.num + n - 3) + '</a></li>';
			}
			html = '<div class="pageTitle">\n      Total <span>' + this.num + '</span> pages\n    </div>\n    <div class="center">\n      <ul class="pagination" id="' + setId + '"><li id="first" page="first">\n\t\t\t\t\t\t\t<span>\n\t\t\t\t\t\t\t\t<i class="icon icon-back"></i>\n\t\t\t\t\t\t\t\t<i class="icon icon-back"></i>\n\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t<li page="prev" id="prev">\n\t\t\t\t\t\t\t<a class="icon icon-back"></a>\n\t\t\t\t\t\t</li>';
			switch (type) {
				case "next":
					if (i <= 4) {
						html += '<li page="1"><a>1</a></li>' + htmlLeft + HL + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
					} else if (i >= set.num - 3) {
						html += '<li page="1"><a>1</a></li>' + HL + htmlRight + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
					} else {
						html += '<li page="1"><a>1</a></li>' + HL + htmlC + HL + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
					}
					break;
				case "prev":
					if (i <= 4) {
						html += '<li page="1"><a>1</a></li>' + htmlLeft + HL + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
					} else if (i >= set.num - 3) {
						html += '<li page="1"><a>1</a></li>' + HL + htmlRight + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
					} else {
						html += '<li page="1"><a>1</a></li>' + HL + htmlC + HL + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
					}
					break;
				case "first":
					html += '<li class="active" page="1"><a>1</a></li>' + htmlLeft + HL + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
					break;
				case "last":
					html += '<li page="1"><a>1</a></li>' + HL + htmlRight + '<li class="active" page="' + set.num + '"><a>' + set.num + '</a></li>';
					break;
				case "jump":
					if (i <= 4) {
						if (i == 1) {
							html += '<li class="active" page="1"><a>1</a></li>' + htmlLeft + HL + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
						} else {
							html += '<li page="1"><a>1</a></li>' + htmlLeft + HL + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
						}
					} else if (i >= set.num - 3 && set.num >= 7) {
						if (i == set.num) {
							html += '<li page="1"><a>1</a></li>' + HL + htmlRight + '<li class="active" page="' + set.num + '"><a>' + set.num + '</a></li>';
						} else {
							html += '<li page="1"><a>1</a></li>' + HL + htmlRight + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
						}
					} else {
						html += '<li page="1"><a>1</a></li>' + HL + htmlC + HL + '<li page="' + set.num + '"><a>' + set.num + '</a></li>';
					}
			}
			html += '<li page="next" id="next">\n\t\t\t\t\t\t\t<a class="icon icon-more"></a>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t<li page="last">\n\t\t\t\t\t\t\t<span id="last">\n\t\t\t\t\t\t\t\t<i class="icon icon-more"></i>\n\t\t\t\t\t\t\t\t<i class="icon icon-more"></i>\n\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t</li></ul>\n    </div>\n    <div class="pageJump">\n      <span>Go to:</span>\n      <input type="text" />\n      <button type="button" class="button">Go</button>\n    </div>';
			if (this.num > 5 || this.num < 3) {
				set.elem.html(html);
				clickpages.init({ num: set.num, elem: set.elem, callback: set.callback });
			}
		}
	};
	if (set.num <= 1) {
		$(".elem").find('.pagination').html('');
		return;
	} else if (parseInt(set.num) <= 6) {
		n = parseInt(set.num);
		var html = '<div class="pageTitle">\n      Total <span>' + set.num + '</span> pages\n    </div>\n    <div class="center">\n      <ul class="pagination" id="' + set.tabclick.substr(1) + '"><li id="first" page="first">\n\t\t\t\t\t\t\t<span>\n\t\t\t\t\t\t\t\t<i class="icon icon-back"></i>\n\t\t\t\t\t\t\t\t<i class="icon icon-back"></i>\n\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t<li page="prev" id="prev">\n\t\t\t\t\t\t\t<a class="icon icon-back"></a>\n\t\t\t\t\t\t</li>';
		for (var i = 1; i <= n; i++) {
			if (i == set.startnum) {
				html += '<li class="active" page="' + i + '"><a>' + i + '</a></li>';
			} else {
				html += '<li page="' + i + '"><a>' + i + '</a></li>';
			}
		}
		html += '<li page="next" id="next">\n\t\t\t\t\t\t\t<a class="icon icon-more"></a>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t<li page="last">\n\t\t\t\t\t\t\t<span id="last">\n\t\t\t\t\t\t\t\t<i class="icon icon-more"></i>\n\t\t\t\t\t\t\t\t<i class="icon icon-more"></i>\n\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t</li></ul>\n    </div>\n    <div class="pageJump">\n      <span>Go to:</span>\n      <input type="text" />\n      <button type="button" class="button">Go</button>\n    </div>';
		set.elem.html(html);
		clickpages.init();
	} else {
		clickpages.newPages("jump", set.startnum);
	}
}

/***/ }),

/***/ "./src/js/common/request.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dialog = __webpack_require__("./src/js/common/dialog.js");

var _dialog2 = _interopRequireDefault(_dialog);

var _jquery = __webpack_require__("jquery");

var _jquery2 = _interopRequireDefault(_jquery);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var lang = "en";
var _csrf_param = window.configs && window.configs["csrf-param"] || (0, _jquery2.default)('meta[name="csrf-param"]').attr('content');
var _csrf_token = window.configs && window.configs["csrf-token"] || (0, _jquery2.default)('meta[name="csrf-token"]').attr('content');
var message_lang = {
    zh: {
        warning: '提示',
        confirm: '确定',
        session_timeout: '您当前的会话已超时，请重新登录。',
        go_to_login: '还没有登录，请前往',
        login: '登录',
        cancel: '取消',
        ok: '确定',
        try_later: '服务出错，请稍后再试',
        error_title: '系统错误'
    },
    en: {
        warning: 'prompt',
        session_timeout: 'Your current session has timed out. Please log in again.',
        go_to_login: 'Not yet logged in, please go ',
        login: 'login',
        cancel: 'cancel',
        confirm: 'confirm',
        ok: 'OK',
        try_later: 'Service error, please try again later',
        error_title: 'system error'
    }
};
var SUCCESS_CODE = '0';
var message = message_lang[lang] || {};

var SuccessResponse = function SuccessResponse(response) {
    _classCallCheck(this, SuccessResponse);

    return {
        type: 'success',
        data: response
    };
};

var ErrorResponse = function ErrorResponse(errorcode) {
    _classCallCheck(this, ErrorResponse);

    return {
        type: 'error',
        data: errorcode
    };
};
/**
 * 接口返回值处理逻辑，如果未捕获到匹配的处置方案，则抛出异常
 * @param {*} response 响应
 * @param {*} options 配置可选项，如忽略错误
 * @return {response}  返回响应
 */


function checkResponse(resdata, options, context) {
    // let {data,code,message} = resdata;
    var data = resdata.data,
        errcode = resdata.errcode,
        errmsg = resdata.errmsg;

    if (errcode > 0) {
        _dialog2.default.alertError(errmsg, { size: 'sm' });
    }
    // console.log(resdata)
    options = options || {};
    if (typeof resdata == 'string') {
        return new SuccessResponse(resdata);
    }
    if (typeof errcode == "undefined") {
        return new ErrorResponse("305");
    }
    if (errcode == SUCCESS_CODE) {
        return new SuccessResponse(data);
    }
    if (!options.ignoreError) {
        errcode = errcode || 'default';
        var errorHandler = context.ErrorHandlers[errcode];
        if (!errorHandler) {
            throw new Error(errmsg || errcode);
        }
        errorHandler(resdata);
        return new ErrorResponse(errcode);
    } else {
        return new ErrorResponse(errcode);
    }
}
// 兜底的错误处理
function handleError(err, options) {
    options = options || {};
    if (!options.ignoreError) {
        dialogMessage(err);
    }
}

function dialogMessage(err) {
    if (err && err.message) {
        _dialog2.default.alertError(message.error_title, err.message, { btns: [message.ok], size: 'sm' });
    } else {
        _dialog2.default.notifyError(message.error_title, { size: 'sm' });
    }
}

var Ajax = function () {
    function Ajax() {
        _classCallCheck(this, Ajax);

        this.ErrorHandlers = {
            'verifyCodeInvalid': function verifyCodeInvalid() {},
            'NoPermission.Directory': function NoPermissionDirectory() {},
            'default': function _default(response) {
                createMessage(response.message || message.try_later);
            },
            '-99': function _(response) {
                _dialog2.default.notifyError(response);
            },
            "404": function _(response) {
                _dialog2.default.notifyError(response.message, { size: 'sm' });
            },
            "403": function _(response) {
                location.href = window.configs && window.configs.loginurl;
            }
        };
    }

    _createClass(Ajax, [{
        key: "addHandler",
        value: function addHandler(key, fn) {
            this.ErrorHandlers[key] = fn;
        }
    }, {
        key: "get",
        value: function get(url) {
            var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

            var context = this;
            return _jquery2.default.get(url, {
                params: params
            }).then(function (res) {
                return checkResponse(res, options, context);
                // return {aa:'bb'};
            }) // 接口通信成功，处理返回值
            .fail(function (err) {
                return handleError(err, options);
            }); // 发生异常，进行兜底处理
        }
    }, {
        key: "getHTML",
        value: function getHTML(url) {
            var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

            var context = this;
            return _jquery2.default.get(url, {
                params: params
            }).fail(function (err) {
                return handleError(err, options);
            }); // 发生异常，进行兜底处理
        }
        /**
         * 发送请求
         * @param {string} url - 请求的接口地址
         * @param {object} data - 请求参数
         * @param {object} options 传递给fetch API的参数
         * @return {promise} 返回promise
         */

    }, {
        key: "post",
        value: function post(url, data) {
            var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

            var context = this;
            var token = {};
            token[_csrf_param] = _csrf_token;

            return _jquery2.default.ajax(url, _extends({
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: _extends({}, data, token)
            }, options)).then(function (data) {
                var result = checkResponse(data, options, context);
                return result;
            }) // 接口通信成功，处理返回值
            .fail(function (err) {
                return handleError(err, options);
            }); // 发生异常，进行兜底处理
        }
    }, {
        key: "jsonp",
        value: function jsonp(url) {
            var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

            // setDefault
            options = _extends({}, defaultOptions, options);
            return _jquery2.default.ajax(url + "?" + JSON.stringify(params), _extends({
                method: 'GET',
                dataType: "jsonp"
            }, options)).then(function (res) {
                var result = checkResponse(res, options);
                return result;
            }) // 接口通信成功，处理返回值
            .fail(function (err) {
                return handleError(err, options);
            }); // 发生异常，进行兜底处理
        }
    }, {
        key: "uploadFile",
        value: function uploadFile(url, files, name) {
            var params = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

            if (window.FormData) {
                var formData = new FormData();
                var token = {};
                token[_csrf_param] = _csrf_token;
                _jquery2.default.each(files, function (i, file) {
                    formData.append(name, file);
                });
                _jquery2.default.each(params, function (key, val) {
                    formData.append(key, val);
                });
                formData.append('yunqi_csrf', _csrf_token);
                return _jquery2.default.ajax({
                    type: "POST",
                    url: url,
                    data: formData,
                    cache: false,
                    processData: false,
                    contentType: false
                }).then(function (res) {
                    var result = checkResponse(res);
                    return result;
                }).fail(function (err) {
                    return handleError(err);
                });
            }
        }
    }]);

    return Ajax;
}();

exports.default = new Ajax();

/***/ }),

/***/ "./src/js/detail.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _request = __webpack_require__("./src/js/common/request.js");

var _request2 = _interopRequireDefault(_request);

var _comment = __webpack_require__("./src/js/detail/comment.ejs");

var _comment2 = _interopRequireDefault(_comment);

var _parent_comment = __webpack_require__("./src/js/detail/parent_comment.ejs");

var _parent_comment2 = _interopRequireDefault(_parent_comment);

var _comment_list = __webpack_require__("./src/js/detail/comment_list.ejs");

var _comment_list2 = _interopRequireDefault(_comment_list);

var _read = __webpack_require__("./src/js/detail/read.ejs");

var _read2 = _interopRequireDefault(_read);

var _like = __webpack_require__("./src/js/detail/like.ejs");

var _like2 = _interopRequireDefault(_like);

var _userinfo = __webpack_require__("./src/js/detail/userinfo.ejs");

var _userinfo2 = _interopRequireDefault(_userinfo);

var _icon_list = __webpack_require__("./src/js/detail/icon_list.ejs");

var _icon_list2 = _interopRequireDefault(_icon_list);

var _bottom_list = __webpack_require__("./src/js/detail/bottom_list.ejs");

var _bottom_list2 = _interopRequireDefault(_bottom_list);

var _article = __webpack_require__("./src/js/detail/article.ejs");

var _article2 = _interopRequireDefault(_article);

__webpack_require__("./src/css/detail.css");

__webpack_require__("./src/css/nav.css");

__webpack_require__("./node_modules/_mditor@1.3.3@mditor/dist/css/mditor.css");

var _pager = __webpack_require__("./src/js/common/pager.js");

var _pager2 = _interopRequireDefault(_pager);

var _jquery = __webpack_require__("./src/js/common/jquery.modal.js");

var _jquery2 = _interopRequireDefault(_jquery);

var _dialog = __webpack_require__("./src/js/common/dialog.js");

var _dialog2 = _interopRequireDefault(_dialog);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* window.configs = {
    "csrf-param": "yunqi_csrf",
    "csrf-token": "S9TO37L12G",
    "islogin": false,
    "registerurl": "https://account.aliyun.test/register/register.htm?from_type=yqclub&oauth_callbac" +
            "k=http%3A%2F%2Fphpwind-dingtalk-test.aliyun.test%3A8067%2Fblog%2F1650%3Fdo%3Dlog" +
            "in",
    "loginurl": "https://account.aliyun.test/login/login.htm?from_type=yqclub&oauth_callback=http" +
            "%3A%2F%2Fphpwind-dingtalk-test.aliyun.test%3A8067%2Fblog%2F1650%3Fdo%3Dlogin",
    "isNeedNickname": false
}; */
$(function () {
    var onPageNum = 1;
    // 修改子评论
    $('.wrap-main-left-comments').on('click', '.children-edit', function () {
        var children_main = $(this).parents('.children-main');
        var value = children_main.children('p').text().trim();
        children_main.hide();
        $(this).parents('dd').children('.children-edit-main').show();
        children_main.siblings('.children-edit-main').children('textarea').val(children_main.children('p').text().trim());
        $(this).parents('dd').children('.children-edit-main').find('.cancel').on('click', function () {
            $(this).parents('.children-edit-main').hide();
            children_main.show();
        });
        $(this).parents('dd').children('.children-edit-main').find('.ensure').on('click', function () {
            var _this = this;

            var cid = $(this).attr('data-cid');
            var id = $(this).attr('data-id');
            var url = window.configs.baseurl + ('/comments/' + cid + '/subcomments/' + id + '?cid=' + cid + '&id=' + id + '&content=' + $(this).parent().siblings('textarea').val());
            if (value != $(this).parent().siblings('textarea').val()) {
                _request2.default.post(url).then(function (res) {
                    $(_this).parents('.children-edit-main').hide();
                    $(_this).parents('.comments-children').before(res.data);
                    $(_this).parents('.comments-children').remove();
                    // children_main.children('p').text($(this).parent().siblings('textarea').val())
                    children_main.show();
                });
            }
        });
    });

    // 显示子评论的添加
    $('.wrap-main-left-comments').on('click', '.children-show', function () {
        $(this).parents('aside').next().toggle();
        $(this).parents('.children-main').next().children('input').val('@' + $(this).parents('aside').siblings('h2').children('a').html().trim() + ' ');
    });
    // 子评论删除
    $('.wrap-main-left-comments').on('click', '.children-del', function () {
        var _this2 = this;

        var cid = $(this).parents('.comments-parent').attr('data-id');
        var id = $(this).attr('data-id');
        var that = this;
        var url = window.configs.baseurl + ('/comments/' + cid + '/subcomments/destroy/' + id);
        _request2.default.post(url).then(function (res) {
            if (res.type == "success") {
                var num = $(that).parents('.comments-parent').find('.parent-show').children('b').text() * 1;
                $(that).parents('.comments-parent').find('.parent-show').children('b').html(num - 1);
                $(_this2).parents('.comments-children').remove();
            }
        });
    });

    // 评论修改
    $('.wrap-main-left-comments').on('click', '.parent-edit', function () {
        var parent_main = $(this).parents('.parent-main');
        var startVal = parent_main.children('p').text().trim();
        parent_main.hide();
        $(this).parents('dd').children('.parent-edit-main').show();
        parent_main.siblings('.parent-edit-main').children('textarea').val(parent_main.children('p').text().trim());
        $(this).parents('dd').children('.parent-edit-main').find('.cancel').on('click', function () {
            $(this).parents('.parent-edit-main').hide();
            parent_main.show();
        });
        $(this).parents('dd').children('.parent-edit-main').find('.ensure').on('click', function () {
            var _this3 = this;

            var value = $(this).parent().siblings('textarea').val();
            var id = $(this).parents('.comments-parent').attr('data-id');
            // /comments/<id>
            var url = window.configs.baseurl + ('/comments/' + id + '?id=' + id + '&content=' + value);
            if (startVal != value) {

                _request2.default.post(url).then(function (res) {
                    $(_this3).parents('.parent-edit-main').hide();
                    // $(this).parents('.comments-parent').html(res)
                    $(_this3).parents('.comments-parent').before(res.data);
                    $(_this3).parents('.comments-parent').remove();
                    parent_main.children('p').text(value);
                    parent_main.show();
                });
            }
        });
    });

    // 显示子评论
    $('.wrap-main-left-comments').on('click', '.parent-show', function () {
        var _this4 = this;

        $(this).parents('.parent-main').next().toggle();
        $(this).toggleClass('show');
        var url = window.configs.baseurl + ('/comments/' + $(this).parents('.comments-parent').attr('data-id') + '/subcomments?p=' + onPageNum);
        if ($(this).hasClass('show')) {
            _request2.default.getHTML(url).done(function (res) {
                $(_this4).parents('.parent-main').next().html('<h5><span></span></h5>' + res);
            });
        }
    });

    // 评论点赞
    $('.wrap-main-left-comments').on('click', '.parent-zan', function () {
        var _this5 = this;

        var num = $(this).children('b').html() * 1;
        var that = this;
        if ($(this).attr('data-islogin') == "true") {
            var uid = $(this).attr('data-id'),
                alreadyState = $(this).attr('data-already'),
                alreadyStr = alreadyState == 'false' ? "voteup" : "unvoteup";
            var url = window.configs.baseurl + ('/comments/' + uid + '/' + alreadyStr + '?type=article');
            _request2.default.post(url).then(function (res) {
                if (res.type == "success") {
                    if (alreadyState == 'false') {
                        num++;
                        $(_this5).children('b').html(num);
                        $(that).attr("data-already", true).toggleClass('zan');
                    } else {
                        num--;
                        $(_this5).children('b').html(num);
                        $(that).attr("data-already", false).toggleClass('zan');
                    }
                }
            });
        } else {
            location.href = window.configs.loginurl;
        }
    });

    // 子评论的点赞
    $('.wrap-main-left-comments').on('click', '.children-zan', function () {
        var _this6 = this;

        var num = $(this).children('b').html() * 1;
        var that = this;
        if ($(this).attr('data-islogin') == "true") {
            var uid = $(this).attr('data-id'),
                cid = $(this).parents('.comments-parent').attr('data-id'),
                alreadyState = $(this).attr('data-already'),
                alreadyStr = alreadyState == 'false' ? "voteup" : "unvoteup";
            var url = window.configs.baseurl + ('/comments/' + cid + '/subcomments/' + uid + '/' + alreadyStr);
            _request2.default.post(url).then(function (res) {
                if (res.type == "success") {
                    if (alreadyState == 'false') {
                        num++;
                        $(_this6).children('b').html(num);
                        $(that).attr("data-already", true).toggleClass('zan');
                    } else {
                        num--;
                        $(_this6).children('b').html(num);
                        $(that).attr("data-already", false).toggleClass('zan');
                    }
                }
            });
        } else {
            location.href = window.configs.loginurl;
        }
    });

    // 评论的删除
    $('.wrap-main-left-comments').on('click', '.parent-del', function () {
        var _this7 = this;

        var value = $(this).parents('aside').siblings('p').html();
        var id = $(this).parents('.comments-parent').attr('data-id');
        var url = window.configs.baseurl + ('/comments/destroy/' + id + '?id=' + id + '&content=' + value.trim());
        _request2.default.post(url).then(function (res) {
            if (res.type == "success") {
                $(_this7).parents('.comments-parent').remove();
            }
        });
    });

    // 显示子评论添加
    $('.wrap-main-left-comments').on('click', '.children-show', function () {
        $(this).parents('.children-main').next().toggle();
        $(this).parents('.children-main').next().children('input').val('@' + $(this).parents('aside').siblings('h2').children('a').html().trim() + ' ');
    });

    // 添加子评论
    $('.wrap-main-left-comments').on('click', '.add-children-comment', function () {
        var _this8 = this;

        var value = $(this).parents('.wrap-main-left-comments-post').children('input').eq(0).val();
        var cid = $(this).attr('data-cid');
        var url = window.configs.baseurl + ('/comments/' + cid + '/subcomments?cid=' + cid + '&content=' + value);
        if (window.configs.islogin) {
            if (value != '') {
                _request2.default.post(url).then(function (res) {
                    $(_this8).parents('.wrap-main-left-comments-post').before(res.data);
                    $(_this8).parents('.wrap-main-left-comments-post').children('input').eq(0).val('');
                    var num = $(_this8).parents('.comments-parent').find('.parent-show').children('b').text() * 1;
                    $(_this8).parents('.comments-parent').find('.parent-show').children('b').html(num + 1);
                });
            }
        } else {
            location.href = window.configs.loginurl;
        }
    });

    $('.wrap-main-left-comments').on('click', '.add-grandson-comment', function () {
        var _this9 = this;

        var that = this;
        var value = $(this).prev().val();
        var cid = $(this).attr('data-cid');
        var url = window.configs.baseurl + ('/comments/' + cid + '/subcomments?cid=' + cid + '&content=' + value);
        if (value != '') {
            _request2.default.post(url).then(function (res) {
                $(that).parents('.comments-children').after(res.data);
                $(that).prev().val('');
                $(_this9).parents('.post').hide();
            });
        }
    });

    function getParentCommentsNum() {
        $('.wrap-main-left-comments').find('.subcomment').each(function (i, j) {
            var id = $(this).prop('id').split('-')[1];
            var num = $(this).attr('data-pageCount');
            $('.comments-parent').each(function () {
                if ($(this).attr('data-id') == id) {
                    $(this).find('.parent-show').children('b').html(num);
                }
            });
        });
    }
    // getParentCommentsNum()
    $('.wrap-main-left-action div a').each(function () {
        $(this).attr('data-url', location.href);
        // console.log('View site '+$(this).attr('data-sharer'))
        $(this).attr('title', 'View site ' + $(this).attr('data-sharer'));
    });
    if ($('#pageCount').attr('data-pagecount') <= 1) {
        $('.page').hide();
    }
    var top = $('#comment').length > 0 ? $('#comment').offset().top : 0;
    (0, _pager2.default)({
        num: $('#pageCount').attr('data-pagecount'), //页码数
        startnum: 1, //指定页码
        elem: $('.parent-page'), //指定的元素
        tabclick: '#parentPage',
        top: top,
        callback: function callback(n) {
            //回调函数
            onPageNum = n;
            var url = window.configs.baseurl + ('/comments?type=article&pid=' + window.localconfigs.aid + '&p=' + n);
            _request2.default.getHTML(url).done(function (res) {
                $('.wrap-main-left-comments').html(res);
            });
        }
    });

    /* Ajax.get('/notifications/detail_article.json').then((res) => {
        $('.wrap-main-left-read').before(article({
            data: {...res.data.article,url:location.href}
        }))
        var userId = res.data.article.id
        $('.action-zan').on('click', function () {
            var num = $(this).children('b').html() * 1
            $(this).toggleClass('zan')
            if ($(this).hasClass('zan')) {
                num++
                Ajax.post('/notifications/post.json',{userId: 0}).then((res) => {
                    console.log(res)
                })
            } else {
                num--
                Ajax.post('/notifications/post.json',{userId: 0}).then((res) => {
                    console.log(res)
                })
            }
            $(this).children('b').html(num)
        })
        $('.action-love').on('click', function () {
            var num = $(this).children('b').html() * 1
            $(this).toggleClass('love')
            if ($(this).hasClass('love')) {
                num++
                Ajax.post('/notifications/post.json',{userId: 0}).then((res) => {
                    console.log(res)
                })
            } else {
                num--
                Ajax.post('/notifications/post.json',{userId: 0}).then((res) => {
                    console.log(res)
                })
            }
            $(this).children('b').html(num)
        })
    }) */
    $('.action-zan').on('click', function () {
        var _this10 = this;

        var num = $(this).children('b').html() * 1;
        var that = this;
        if ($(this).attr('data-islogin') == "true") {
            var uid = $(this).attr('data-id'),
                alreadyState = $(this).attr('data-already'),
                alreadyStr = alreadyState == 'false' ? "up" : "down";
            var url = window.configs.baseurl + ('/yqapi/vote/' + alreadyStr + '?type=article&id=' + uid);
            _request2.default.post(url).then(function (res) {
                if (res.type == "success") {
                    if (alreadyState == 'false') {
                        num++;
                        $(_this10).children('b').html(num);
                        $(that).attr("data-already", true).toggleClass('zan');
                    } else {
                        num--;
                        $(_this10).children('b').html(num);
                        $(that).attr("data-already", false).toggleClass('zan');
                    }
                }
            });
        } else {
            location.href = window.configs.loginurl;
        }
    });
    $('.action-love').on('click', function () {
        var _this11 = this;

        var num = $(this).children('b').html() * 1;
        var that = this;
        if ($(this).attr('data-islogin') == "true") {
            var uid = $(this).attr('data-id'),
                alreadyState = $(this).attr('data-already'),
                alreadyStr = alreadyState == 'false' ? "do" : "undo";
            var url = window.configs.baseurl + ('/yqapi/mark/' + alreadyStr + '?markType=article&id=' + uid);
            _request2.default.post(url).then(function (res) {
                if (res.type == "success") {
                    if (alreadyState == 'false') {
                        num++;
                        $(_this11).children('b').html(num);
                        $(that).attr("data-already", true).toggleClass('love');
                    } else {
                        num--;
                        $(_this11).children('b').html(num);
                        $(that).attr("data-already", false).toggleClass('love');
                    }
                }
            });
        } else {
            location.href = window.configs.loginurl;
        }
    });

    /*  parentEdit()
     // parentShow()
     parentDel()
     parentZan()
     childrenEdit()
     childrenShow()
     // childrenDel()
     childrenZan()
     addChildrenComment()
     addGrandsonComment() */
    // 添加评论
    $('.add-parent-comment').click(function () {
        var _this12 = this;

        // /comments
        var value = $(this).parent().prev().val();
        var url = window.configs.baseurl + ('/comments?pid=' + window.localconfigs.aid + '&content=' + value);
        if (window.configs.islogin) {
            if (value != '') {
                _request2.default.post(url).then(function (res) {
                    $('.wrap-main-left-comments').append(res.data);
                    $(_this12).parent().prev().val('');
                });
            }
        } else {
            location.href = window.configs.loginurl;
        }
    });
    /* }) */
    requirejs(['https://g.alicdn.com/aliyun-international/common-assert/0.0.8/js/sharer.min.js'], function () {
        console.log(window.Sharer.init());
    });

    $('.follow-btn').on("click", function () {
        var that = this;

        if ($(this).attr('data-islogin') == "true") {
            var uid = $(this).attr('data-uid'),
                followedState = $(this).attr('data-isfollowed'),
                followedStr = followedState == 'false' ? "do" : "undo";
            var followUrl = window.configs.baseurl + ('/yqapi/follow/' + followedStr + '?followType=user&id=' + uid);
            var num = $(this).prev().children('.followers-num').text() * 1;
            _request2.default.post(followUrl).then(function (res) {
                if (res.type == "success") {
                    if (followedState == 'false') {

                        $('.followers-num').html(num + 1);
                        $(that).attr("data-isfollowed", true).html('Unfollow');
                    } else {
                        $('.followers-num').html(num - 1);
                        $(that).attr("data-isfollowed", false).html('Follow');
                    }
                }
            });
        } else {
            location.href = window.configs.loginurl;
        }
    });

    $('.del-article').click(function () {
        _dialog2.default.alertPrompt('Warning', 'Are you sure you want to delete this post?', {
            btns: [{
                id: 'cancelDel',
                text: 'No'
            }, {
                id: 'sureDel',
                text: 'Yes',
                fn: function fn() {
                    var url = '/blog/destroy/' + window.localconfigs.aid;
                    $.jqmodal.close();
                    _request2.default.post(url).then(function (res) {
                        if (res.type == 'success') {
                            _dialog2.default.notifySuccess('You post has been successfully deleted!', { size: 'sm' });
                            if (location.href.split('.')[0] == 'https://www') {
                                location.href = 'https://www.alibabacloud.com/blog';
                            } else {
                                location.href = 'https://community.alibabacloud.com';
                            }
                        }
                    });
                }
            }]
        });
    });
    $(window).scroll(function () {
        if ($(this).scrollTop() + $(this).height() >= $('.wrap-main').innerHeight()) {
            $('.wrap-main-iconBox').fadeOut(300);
        } else {
            $('.wrap-main-iconBox').fadeIn(300);
        }
    });

    if (window.configs.islogin && window.configs.isNeedNickname && !localStorage['close']) {
        $('body').append('<div class="set-name-box">\n        <div class="set-name-main">\n            <h1>Your Nickname <span class="set-name-close"></span></h1>\n            <p>Please enter a nickname first to make more friends!</p>\n            <input type="text" placeholder="Max allowed 12 characters" class="int-name">\n            <main>\n                <span class="set-name-close-btn">Not Now</span>\n                <button class="submit-name">Save</button>\n            </main>\n        </div>\n    </div>');
    }
    $('.set-name-close,.set-name-close-btn').click(function () {
        $('.set-name-box').remove();
        localStorage['close'] = true;
    });
    $('.submit-name').click(function () {
        if ($('.int-name').val() == '') {
            _dialog2.default.notifyError('Modify the nickname not to be empty!', { size: 'sm' });
        } else {
            _request2.default.post(window.configs.baseurl + '/settings/nickname', { nickname: $('.int-name').val() }).then(function (res) {
                if (res.type == 'success') {
                    _dialog2.default.notifySuccess('Your nickname has been saved.', {
                        size: 'sm'
                    });
                    localStorage['close'] = true;
                    location.reload();
                }
            });
        }
    });
    // Ajax.jsonp('https://www.alibabacloud.com/zh/b/b-alicloud-v3-bottom?callback=jQuery22008679818795374594_1530855547001&isJsonp=yes', {}, {}).done((res) => {
    //         console.log(res)
    //     })
    $.ajax({
        url: 'https://www.alibabacloud.com/en/b/b-alicloud-v3-bottom',
        dataType: 'jsonp',
        method: 'get',
        data: { isJsonp: 'yes' },
        success: function success(res) {
            $('.wrap').after(res);
        },
        error: function error(err) {
            console.log(err);
        }
    });
});

/***/ }),

/***/ "./src/js/detail/article.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {

 if (data) { ;
__p += '\n<h1>\n    ' +
((__t = ( data.title  )) == null ? '' : __t) +
'\n</h1>\n<aside>\n    <main>\n        <a href="' +
((__t = ( data.author_url )) == null ? '' : __t) +
'">' +
((__t = ( data.author )) == null ? '' : __t) +
'</a>\n        <span>' +
((__t = ( data.time  )) == null ? '' : __t) +
'</span>\n        <span>\n            <img src="https://img.alicdn.com/tfs/TB19L9AbXuWBuNjSspnXXX1NVXa-40-26.png" alt=""> ' +
((__t = ( data.views  )) == null ? '' : __t) +
'\n        </span>\n        <span>\n            <i class="icon icon-pinglun"></i>' +
((__t = ( data.comments  )) == null ? '' : __t) +
'\n        </span>\n    </main>\n    <div>\n        <span>Edit</span> |\n        <span>Delete</span>\n    </div>\n</aside>\n<div class="wrap-main-left-abstract">\n    <span>Abstract：</span>' +
((__t = ( data.abstract  )) == null ? '' : __t) +
'\n</div>\n<div class="wrap-main-left-article">\n    ' +
((__t = ( data.content  )) == null ? '' : __t) +
'\n</div>  \n<div class="wrap-main-left-bar">\n    ';
 data.item.forEach(function (i) { ;
__p += '\n    <a href="' +
((__t = ( i.url )) == null ? '' : __t) +
'">' +
((__t = ( i.text )) == null ? '' : __t) +
'</a>\n    ';
 }) ;
__p += '\n</div>\n<div class="wrap-main-left-action">\n    <main>\n        <span>\n            <i class="icon icon-pinglun"></i>\n            ' +
((__t = ( data.comments )) == null ? '' : __t) +
'\n        </span>\n        <span class="action-zan ';
 if (data.is_zan) { ;
__p += 'zan';
 } ;
__p += '">\n            <i class="icon icon-zan"></i>\n            <b>' +
((__t = ( data.zan )) == null ? '' : __t) +
'</b>\n        </span>\n        <span class="action-love ';
 if (data.is_like) { ;
__p += 'love';
 } ;
__p += '">\n            <i class="icon icon-love"></i>\n            <b>' +
((__t = ( data.like )) == null ? '' : __t) +
'</b>\n        </span>\n    </main>\n    <div>\n        <b>Share on</b>\n        <a href="" class="sharer" data-sharer="linkedin" data-url="' +
((__t = ( data.url )) == null ? '' : __t) +
'" >\n            <i class="icon icon-linkedin1"></i>\n        </a>\n        <a href="" class="sharer" data-sharer="facebook" data-url="' +
((__t = ( data.url )) == null ? '' : __t) +
'">\n            <i class="icon icon-lianshu1"></i>\n        </a>\n        <a href="" class="sharer" data-sharer="twitter" data-url="' +
((__t = ( data.url )) == null ? '' : __t) +
'">\n            <i class="icon icon-twitter1"></i>\n        </a>\n        <a href="" class="sharer" data-sharer="googleplus" data-url="' +
((__t = ( data.url )) == null ? '' : __t) +
'">\n            <i class="icon icon-google1"></i>\n        </a>\n\n    </div>\n</div>\n\n';
 } ;


}
return __p
}

/***/ }),

/***/ "./src/js/detail/bottom_list.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {

 if (data) { ;
__p += '<div>\n    <p>\n        <b>\n            ' +
((__t = ( data.title )) == null ? '' : __t) +
'\n        </b>\n        <span>\n            ' +
((__t = ( data.userName )) == null ? '' : __t) +
'\n        </span>\n    </p>\n    <main>\n        <span>\n            ' +
((__t = ( data.btn_text )) == null ? '' : __t) +
'\n        </span>\n        <i class="icon icon-more"></i>\n    </main>\n</div>\n<ul>\n    ';
 data.item.forEach(function (i) { ;
__p += '\n        <li>\n            <a href="' +
((__t = ( i.url )) == null ? '' : __t) +
'">' +
((__t = ( i.text )) == null ? '' : __t) +
'</a>\n        </li>\n        ';
 }) ;
__p += '\n</ul>\n</div>\n</div>\n';
 } ;


}
return __p
}

/***/ }),

/***/ "./src/js/detail/comment.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {

 if (option) { ;
__p += '\n<div class="comments-children"  data-id=' +
((__t = ( option.id )) == null ? '' : __t) +
'>\n    <dl>\n        <dt>\n            <a href="' +
((__t = ( option.user_url )) == null ? '' : __t) +
'">\n                <img src="' +
((__t = ( option.userImg )) == null ? '' : __t) +
'" alt="">\n            </a>\n        </dt>\n        <dd>\n            <div class="children-edit-main">\n                <textarea name="" id="" cols="30" rows="3"></textarea>\n                <main>\n                    <button class="btn btn-default cancel">cancel</button>\n                    <button class="btn btn-primary ensure">ensure</button>\n                </main>\n            </div>\n            <div class="children-main">\n                <h2>\n                    <a href="' +
((__t = ( option.user_url )) == null ? '' : __t) +
'">\n                        ' +
((__t = ( option.userName )) == null ? '' : __t) +
'\n                    </a>\n                    <span>\n                        ' +
((__t = ( option.time )) == null ? '' : __t) +
'\n                    </span>\n                </h2>\n                <p>\n                    ' +
((__t = ( option.text )) == null ? '' : __t) +
'\n                </p>\n                <aside>\n                    <p>\n                        <span class="children-zan">\n                            <i class="icon icon-zan"></i>\n                            <b>\n                                ' +
((__t = ( option.like )) == null ? '' : __t) +
'\n                            </b>\n                        </span>\n                        <span class="children-show">\n                            <i class="icon icon-pinglun"></i>\n                            <b>\n                                ' +
((__t = ( option.comments )) == null ? '' : __t) +
'\n                            </b>\n                        </span>\n                    </p>\n                    <div>\n                        <span class="children-edit">Edit</span> |\n                        <span class="children-del">Delete</span>\n                    </div>\n                </aside>\n            </div>\n            <div class="post">\n                <input type="text" placeholder="@ Li Xiang">\n                <button class="add-grandson-comment">\n                    Post\n                </button>\n            </div>\n        </dd>\n    </dl>\n</div>\n';
 } ;


}
return __p
}

/***/ }),

/***/ "./src/js/detail/comment_list.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {

 if (data) { ;
__p += '\n';
 data.forEach(function (i) { ;
__p += '\n    <dl class="comments-parent" data-id=' +
((__t = ( i.id )) == null ? '' : __t) +
'>\n        <dt>\n            <a href="' +
((__t = ( i.user_url )) == null ? '' : __t) +
'">\n                <img src="' +
((__t = ( i.userImg )) == null ? '' : __t) +
'" alt="">\n            </a>\n        </dt>\n        <dd>\n            <div class="parent-edit-main">\n                <textarea name="" id="" cols="30" rows="3"></textarea>\n                <main>\n                    <button class="btn btn-default cancel">cancel</button>\n                    <button class="btn btn-primary ensure">ensure</button>\n                </main>\n            </div>\n            <div class="parent-main">\n                <h2>\n                    <a href="' +
((__t = ( i.user_url )) == null ? '' : __t) +
'">\n                        ' +
((__t = ( i.userName )) == null ? '' : __t) +
'\n                    </a>\n                    <span>\n                        ' +
((__t = ( i.time )) == null ? '' : __t) +
'\n                    </span>\n                </h2>\n                <p>\n                    ' +
((__t = ( i.text )) == null ? '' : __t) +
'\n                </p>\n                <aside>\n                    <main>\n                        <span class="parent-zan ';
 if (i.zan) { ;
__p += 'zan';
 } ;
__p += '">\n                            <i class="icon icon-zan"></i>\n                            <b>\n                                ' +
((__t = ( i.like )) == null ? '' : __t) +
'\n                            </b>\n                        </span>\n                        <span class="parent-show">\n                            <i class="icon icon-pinglun"></i>\n                            <b>\n                                ' +
((__t = ( i.comments )) == null ? '' : __t) +
'\n                            </b>\n                        </span>\n                    </main>\n                    ';
 if(i.me) { ;
__p += '\n                        <div>\n                            <span class="parent-edit">Edit</span> |\n                            <span class="parent-del">Delete</span>\n                        </div>\n                        ';
 } ;
__p += '\n                </aside>\n            </div>\n            <section>\n                <h5>\n                    <span></span>\n                </h5>\n                ';
 i.child.forEach(function (j) { ;
__p += '\n                    <div class="comments-children" data-id=' +
((__t = ( j.id )) == null ? '' : __t) +
'>\n                        <dl>\n                            <dt>\n                                <a href="' +
((__t = ( i.user_url )) == null ? '' : __t) +
'">\n                                    <img src="' +
((__t = ( j.userImg )) == null ? '' : __t) +
'" alt="">\n                                </a>\n                            </dt>\n                            <dd>\n                                <div class="children-edit-main">\n                                    <textarea name="" id="" cols="30" rows="3"></textarea>\n                                    <main>\n                                        <button class="btn btn-default cancel">cancel</button>\n                                        <button class="btn btn-primary ensure">ensure</button>\n                                    </main>\n                                </div>\n                                <div class="children-main">\n                                    <h2>\n                                        <a href="' +
((__t = ( j.user_url )) == null ? '' : __t) +
'">\n                                            ' +
((__t = ( j.userName )) == null ? '' : __t) +
'\n                                        </a>\n                                        <span>\n                                            ' +
((__t = ( j.time )) == null ? '' : __t) +
'\n                                        </span>\n                                    </h2>\n                                    <p>\n                                        ' +
((__t = ( j.text )) == null ? '' : __t) +
'\n                                    </p>\n                                    <aside>\n                                        <p>\n                                            <span class="children-zan ';
 if (i.zan) { ;
__p += 'zan';
 } ;
__p += '">\n                                                <i class="icon icon-zan"></i>\n                                                <b>\n                                                    ' +
((__t = ( j.like )) == null ? '' : __t) +
'\n                                                </b>\n                                            </span>\n                                            <span class="children-show">\n                                                <i class="icon icon-pinglun"></i>\n                                                <b>\n                                                    ' +
((__t = ( j.comments )) == null ? '' : __t) +
'\n                                                </b>\n                                            </span>\n                                        </p>\n                                        ';
 if(j.me) { ;
__p += '\n                                            <div>\n                                                <span class="children-edit">Edit</span> |\n                                                <span class="children-del">Delete</span>\n                                            </div>\n                                            ';
 } ;
__p += '\n                                    </aside>\n                                </div>\n                                <div class="post">\n                                    <input type="text" placeholder="@ Li Xiang">\n                                    <button class="add-grandson-comment">\n                                        Post\n                                    </button>\n                                </div>\n                            </dd>\n                        </dl>\n                    </div>\n                    ';
 }) ;
__p += '\n                        <main class="wrap-main-left-comments-post">\n                            <input type="text" placeholder="Write your comment...">\n                            <p>\n                                <button class="add-children-comment">\n                                    Post\n                                </button>\n                            </p>\n                        </main>\n            </section>\n        </dd>\n    </dl>\n    ';
 }) ;
__p += '\n';
 } ;


}
return __p
}

/***/ }),

/***/ "./src/js/detail/icon_list.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {
__p += '\n';
 if (title) { ;
__p += '\n    <h1>\n        ' +
((__t = ( title )) == null ? '' : __t) +
'\n    </h1>\n';
 } ;
__p += '\n';
 if (item) { ;
__p += '\n<ul>\n    ';
 item.forEach(function (i,index) { ;
__p += '\n            <li>\n                <h2>\n                    <a href="' +
((__t = ( i.title_url )) == null ? '' : __t) +
'"><img src="' +
((__t = ( i.icon )) == null ? '' : __t) +
'" alt="">\n                    ' +
((__t = ( i.title )) == null ? '' : __t) +
'</a>\n                </h2>\n                <p>\n                    ' +
((__t = ( i.text )) == null ? '' : __t) +
'\n                </p>\n                <a href="' +
((__t = ( i.btn_url )) == null ? '' : __t) +
'" class="btn btn-default">\n                    ' +
((__t = ( i.btn_text )) == null ? '' : __t) +
'\n                </a>\n            </li>\n    ';
 }) ;
__p += '\n</ul>\n';
 } ;


}
return __p
}

/***/ }),

/***/ "./src/js/detail/like.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {

 if (data) { ;
__p += '\n    ';
 data.forEach(function (i) { ;
__p += '\n    <li>\n        <span></span>\n        <a href="' +
((__t = ( i.url )) == null ? '' : __t) +
'">' +
((__t = ( i.text )) == null ? '' : __t) +
'</a>\n            <p>\n                ' +
((__t = ( i.userName )) == null ? '' : __t) +
' -\n                    ' +
((__t = ( i.time )) == null ? '' : __t) +
'\n            </p>\n    </li>\n    ';
 }) ;
__p += '\n';
 } ;
__p += '\n\n';

}
return __p
}

/***/ }),

/***/ "./src/js/detail/parent_comment.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {

 if (option) { ;
__p += '\n    <dl class="comments-parent" data-id=' +
((__t = ( option.id )) == null ? '' : __t) +
'>\n        <dt>\n            <a href="' +
((__t = ( option.user_url )) == null ? '' : __t) +
'">\n                <img src="' +
((__t = ( option.userImg )) == null ? '' : __t) +
'" alt="">\n            </a>\n        </dt>\n        <dd>\n            <div class="parent-edit-main">\n                <textarea name="" id="" cols="30" rows="3"></textarea>\n                <main>\n                    <button class="btn btn-default cancel">cancel</button>\n                    <button class="btn btn-primary ensure">ensure</button>\n                </main>\n            </div>\n            <div class="parent-main">\n                <h2>\n                    <a href="' +
((__t = ( option.user_url )) == null ? '' : __t) +
'">\n                        ' +
((__t = ( option.userName )) == null ? '' : __t) +
'\n                    </a>\n                    <span>\n                        ' +
((__t = ( option.time )) == null ? '' : __t) +
'\n                    </span>\n                </h2>\n                <p>\n                    ' +
((__t = ( option.text )) == null ? '' : __t) +
'\n                </p>\n                <aside>\n                    <main>\n                        <span class="parent-zan">\n                            <i class="icon icon-zan"></i>\n                            <b>\n                                ' +
((__t = ( option.like )) == null ? '' : __t) +
'\n                            </b>\n                        </span>\n                        <span class="parent-show">\n                            <i class="icon icon-pinglun"></i>\n                            <b>\n                                ' +
((__t = ( option.comments )) == null ? '' : __t) +
'\n                            </b>\n                        </span>\n                    </main>\n                    <div>\n                        <span class="parent-edit">Edit</span> |\n                        <span class="parent-del">Delete</span>\n                    </div>\n                </aside>\n            </div>\n            <section>\n                <h5>\n                    <span></span>\n                </h5>\n                <main class="wrap-main-left-comments-post">\n                    <input type="text" placeholder="Write your comment...">\n                    <p>\n                        <button class="add-children-comment">\n                            Post\n                        </button>\n                    </p>\n                </main>\n            </section>\n        </dd>\n    </dl>\n ';
 } ;
__p += '   ';

}
return __p
}

/***/ }),

/***/ "./src/js/detail/read.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {

 if (data) { ;
__p += '\n    ';
 data.forEach(function (i) { ;
__p += '\n        <main>\n            <h2>\n                ' +
((__t = ( i.title )) == null ? '' : __t) +
'\n            </h2>\n            <p>\n                <a href="' +
((__t = ( i.url )) == null ? '' : __t) +
'">' +
((__t = ( i.text )) == null ? '' : __t) +
'</a>\n            </p>\n        </main>\n    ';
 }) ;
__p += '\n';
 } ;
__p += '       ';

}
return __p
}

/***/ }),

/***/ "./src/js/detail/userinfo.ejs":
/***/ (function(module, exports) {

module.exports = function (obj) {
obj || (obj = {});
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
with (obj) {

 if (data) { ;
__p += '\n    <dl>\n        <dt>\n            <img src="' +
((__t = ( data.img )) == null ? '' : __t) +
'" alt="">\n        </dt>\n        <dd>\n            <h1>\n                ' +
((__t = ( data.userName )) == null ? '' : __t) +
'\n            </h1>\n            <p>\n                ' +
((__t = ( data.posts_num )) == null ? '' : __t) +
' posts |\n                    ' +
((__t = ( data.followers_num )) == null ? '' : __t) +
' followers\n            </p>\n            <a href="' +
((__t = ( data.url )) == null ? '' : __t) +
'">Follow</a>\n        </dd>\n    </dl>\n';
 } ;


}
return __p
}

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("./src/js/detail.js");


/***/ }),

/***/ "jquery":
/***/ (function(module, exports) {

module.exports = $;

/***/ })

/******/ });