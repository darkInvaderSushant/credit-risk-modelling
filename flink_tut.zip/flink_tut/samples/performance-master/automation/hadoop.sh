#!/bin/bash

. ./config.sh
. ./utils.sh




$HADOOP_BIN $@
