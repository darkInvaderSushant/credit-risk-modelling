/home/robert/yarn-chaos-monkey/run.sh --appId $1 --sleepBetweenFailuresSec 60
